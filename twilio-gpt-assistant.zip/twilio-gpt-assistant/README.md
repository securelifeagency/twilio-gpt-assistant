# Twilio GPT Assistant

This assistant answers incoming calls, prompts language selection, and connects with OpenAI and Square for scheduling.

### Features:
- English/Spanish prompt
- GPT-4o integration
- Appointment booking (Square)
- Call transfer (to real agents)

### Setup
1. Rename `.env.example` to `.env` and insert your keys.
2. Deploy via Render (connect GitHub repo).
3. Set environment variables in Render dashboard.
