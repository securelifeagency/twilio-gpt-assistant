const twilio = require('twilio');
const VoiceResponse = twilio.twiml.VoiceResponse;
const { OpenAI } = require('openai');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

exports.handleCall = async (req, res) => {
  const twiml = new VoiceResponse();
  const gather = twiml.gather({
    input: 'speech',
    language: 'en-US',
    hints: 'English, Spanish',
    timeout: 5,
    action: '/language',
    method: 'POST'
  });

  gather.say('Thank you for calling Secure Life Insurance. To continue in English, say English. Para continuar en español, diga español.');

  res.type('text/xml');
  res.send(twiml.toString());
};
